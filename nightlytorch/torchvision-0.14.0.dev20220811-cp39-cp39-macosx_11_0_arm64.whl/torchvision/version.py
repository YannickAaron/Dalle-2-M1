__version__ = '0.14.0.dev20220811'
git_version = '203cfb02ef46a0bff9169cf40e8988da0536fbc7'
from torchvision.extension import _check_cuda_version
if _check_cuda_version() > 0:
    cuda = _check_cuda_version()
